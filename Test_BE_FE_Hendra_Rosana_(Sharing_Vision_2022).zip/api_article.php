<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
ob_start();
class Api_article extends CI_Controller
{
	public function select_article_table_status(){
	    $status = $this->input->get('status');
	    $query = $this->db->query("select Id, Title, Content, Category, Created_date, Update_date, Status from article where Status = '$status'");
	    $data = [];
        foreach($query->result() as $row){
            $data[] = $row;
        }
        echo json_encode($data); 
	}
    
	public function select_article_table_num_status(){
	    $status = $this->input->get('status');
	    $query = $this->db->query("select Id from article where Status = '$status'");
        $data['count'] = $query->num_rows();
        echo json_encode($data);
	}
	
	public function select_article_table(){
	    $search = $this->input->get('search');
	    $orderby = $this->input->get('orderby');
	    $pages = $this->input->get('pages');
	    $limit = $this->input->get('limit');
	    $query = $this->db->query("select Id, Title, Content, Category, Created_date, Update_date, Status from article where Id <> '' $search order by ".$orderby." limit ".$pages.",".$limit);
	    $data = [];
        foreach($query->result() as $row){
            $data[] = $row;
        }
        echo json_encode($data); 
	}
	
	public function select_article_table_id(){
	    $a = $this->input->get('ID');
	    $query = $this->db->query("select Id, Title, Content, Category, Created_date, Update_date, Status from article where Id = '$a'");
	    $data = [];
        foreach($query->result() as $row){
            $data[] = $row;
        }
        echo json_encode($data); 
	}
	
	public function insert_article_table(){
	    $Title = $this->input->get('Title');
	    $Content = $this->input->get('Content');
	    $Category = $this->input->get('Category');
	    $Status = $this->input->get('Status');
	    $date = date('Y-m-d H:i:s');
	    return $this->db->query("insert into article(Title, Content, Category, Status, Created_date, Update_date)values('$Title', '$Content', '$Category', '$Status', '$date', '$date')");
	}
	
	public function update_article_table_id(){
	    $a = $this->input->get('ID');
	    $Title = $this->input->get('Title');
	    $Content = $this->input->get('Content');
	    $Category = $this->input->get('Category');
	    $Status = $this->input->get('Status');
	    $date = date('Y-m-d H:i:s');
	    return $this->db->query("update article set Title = '$Title', Content = '$Content', Category = '$Category', Status = '$Status', Update_date = '$date' where Id = '$a'");
	}
	
	public function delete_article_table_id(){
	    $a = $this->input->get('ID');
	    return $this->db->query("delete from article where Id = '$a'");
	}
    
	public function select_article_table_num(){
	    $search = $this->input->get('search');
	    $orderby = $this->input->get('orderby');
	    $pages = $this->input->get('pages');
	    $limit = $this->input->get('limit');
	    $query = $this->db->query("select Id from article where Id <> '' $search order by ".$orderby." limit ".$pages.",".$limit);
        $data['count'] = $query->num_rows();
        echo json_encode($data);
	}
    
	public function select_article_table_num2(){
	    $search = $this->input->get('search');
	    $orderby = $this->input->get('orderby');
	    $pages = $this->input->get('pages');
	    $limit = $this->input->get('limit');
	    $query = $this->db->query("select Id from article where Id <> '' $search order by ".$orderby);
        $data['count'] = $query->num_rows();
        echo json_encode($data);
	}
	
	public function update_article_table(){
	    $search = $this->input->get('search');
	    $orderby = $this->input->get('orderby');
	    $pages = $this->input->get('pages');
	    $limit = $this->input->get('limit');
	    $query = $this->db->query("select Id, Title, Content, Category, Created_date, Update_date, Status from article where Id <> '' $search order by ".$orderby." limit ".$pages.",".$limit);
	    $data = [];
        foreach($query->result() as $row){
            $data[] = $row;
        }
        echo json_encode($data); 
	}
}
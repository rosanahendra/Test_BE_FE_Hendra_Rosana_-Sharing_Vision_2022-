-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 31, 2022 at 08:45 PM
-- Server version: 10.5.15-MariaDB-cll-lve
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u7029827_payment`
--

-- --------------------------------------------------------

--
-- Table structure for table `article`
--

CREATE TABLE `article` (
  `Id` int(11) NOT NULL,
  `Title` varchar(200) NOT NULL,
  `Content` text NOT NULL,
  `Category` varchar(100) NOT NULL,
  `Created_date` timestamp NULL DEFAULT NULL,
  `Update_date` timestamp NULL DEFAULT NULL,
  `Status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `article`
--

INSERT INTO `article` (`Id`, `Title`, `Content`, `Category`, `Created_date`, `Update_date`, `Status`) VALUES
(1, 'Contoh Berita 1 Contoh Berita 1Contoh Berita 1Contoh Berita 1 Contoh Berita 1', 'Berita yang menggembirakan 1 Berita yang menggembirakan 1 Berita yang menggembirakan 1 Berita yang menggembirakan 1 Berita yang menggembirakan 1 Berita yang menggembirakan 1 Berita yang menggembirakan 1 Berita yang menggembirakan 1 Berita yang menggembirakan 1 Berita yang menggembirakan 1', 'Politik', '2022-05-30 05:51:48', '2022-05-31 13:30:37', 'Publish'),
(2, 'Contoh Berita 2', 'Berita yang menggembirakan 2', 'Hiburan', '2022-05-31 05:51:48', '2022-06-01 05:51:48', 'Draft'),
(3, 'Contoh Berita 3', 'Berita yang menggembirakan 11', 'Olahraga', '2022-06-02 05:53:07', '2022-05-31 08:45:28', 'Publish'),
(4, 'Berita Baru', 'begini berita nya', 'Politik', '2022-05-31 08:46:31', '2022-05-31 08:46:31', 'Trashed'),
(6, 'Bagus', 'berita hantu', 'Hantu', '2022-05-31 09:01:31', '2022-05-31 09:01:31', 'Draft');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `article`
--
ALTER TABLE `article`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
